total_value = 0; #global variable

def sum( arg1, arg2 ):
    total_value = arg1 + arg2; #local variable
    print ("This is the total value inside of the local variable: ", total_value)
    return total_value;
sum( 10,20 );
print ("This is the total value outside of the global varaible : ", total_value)
