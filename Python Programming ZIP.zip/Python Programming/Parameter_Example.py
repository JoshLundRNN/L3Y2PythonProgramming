def my_function(drink = "Pepsi"): #This is the default value.
    print("My favourite drink is " + drink)


my_function("Coke")
my_function("Fanta")
my_function("Tango")
my_function()


