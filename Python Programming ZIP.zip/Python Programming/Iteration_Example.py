people_active_today = 0

server_active = True

while people_active_today < 1000:
        server_active == True
        people_active_today = people_active_today + 1
        print(people_active_today, "Active users in the past 24 hours")
        


while server_active == True:
    if people_active_today < 1000:
        people_active_today = people_active_today + 0
        print(people_active_today)
        server_active = False
    print("There have been", people_active_today, "active users in the past 24 hours")
    server_active = False
    

