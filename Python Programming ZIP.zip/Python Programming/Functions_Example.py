def my_function(petname):
	print(petname + " make great pets! ")

my_function("Dogs")
my_function("Cats")
my_function("Birds")
my_function("Rabbits")
my_function("Hamsters")
my_function("Lizards")

print("These are some examples of great pets!")

