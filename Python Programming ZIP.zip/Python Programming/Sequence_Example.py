print ("I am the first line of text, this means I will print first")
print ("I am the second line of text, this means I will be printed second")
print ("This sequence will continue for each line of text that is added, for example: this would be the third line of text")