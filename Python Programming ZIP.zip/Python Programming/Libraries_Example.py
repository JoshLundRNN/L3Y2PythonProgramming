#This is an example of a command in the basic python library, this command is named
#"datetime" which is used to determine the date and time

import datetime

x = datetime.datetime.now()
y = datetime.datetime(2020, 11, 4, 17, 13, 12)
print("This was code was written on", y)
print ("Today's date is", x)


import random

print("Your randomly generated number is :", random.randrange(1, 100))

import math

print("here is pi:", math.pi)


