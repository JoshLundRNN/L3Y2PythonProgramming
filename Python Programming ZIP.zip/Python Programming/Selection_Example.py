#Selection-------

age = int(input("Please enter your age to continue: "))
older = "successful"
younger = "unsuccessful"
if age < 13:
    print("Sorry, you are too young to access this content.: ", younger)
else:
    print("User is 13+, All access has been granted. Enjoy!: ", older) 
